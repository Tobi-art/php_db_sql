-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 25, 2021 at 10:26 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zairyou_kanri`
--

-- --------------------------------------------------------

--
-- Table structure for table `user1`
--

CREATE TABLE `user1` (
  `id` int(12) NOT NULL,
  `category` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `item` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `expire` date NOT NULL,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user1`
--

INSERT INTO `user1` (`id`, `category`, `item`, `location`, `expire`, `indate`) VALUES
(1, 'カップ麺', '焼きそば', 'キチンキャビネット', '2022-01-25', '2021-03-24 12:50:34'),
(2, 'カップ麺', '焼きそば', 'キチンキャビネット', '2022-01-25', '2021-03-24 12:50:34'),
(3, 'カップ麺', '焼きそば', 'キチンキャビネット', '2022-01-25', '2021-03-24 12:50:34'),
(4, 'カップ麺', '焼きそば', 'キチンキャビネット', '2021-07-21', '2021-03-24 12:50:57'),
(5, 'カップ麺', '焼きそば', 'キチンキャビネット', '2021-07-21', '2021-03-24 12:50:57'),
(6, 'カップ麺', '味噌ラーメン', 'キチンキャビネット', '2022-12-26', '2021-03-24 12:51:22'),
(7, 'カップ麺', '味噌ラーメン', 'キチンキャビネット', '2022-12-26', '2021-03-24 12:51:22'),
(8, 'カップ麺', '味噌ラーメン', 'キチンキャビネット', '2022-12-26', '2021-03-24 12:51:22'),
(9, '缶詰', '鯖味噌煮', '冷蔵庫', '2025-05-24', '2021-03-24 12:51:42'),
(10, '缶詰', '鯖味噌煮', '冷蔵庫', '2025-05-24', '2021-03-24 12:51:42'),
(11, '缶詰', '鯖味噌煮', '冷蔵庫', '2025-05-24', '2021-03-24 12:51:42'),
(12, '缶詰', '鯖トマト煮', '冷蔵庫', '2024-05-19', '2021-03-24 12:52:03'),
(13, '缶詰', '鯖トマト煮', '冷蔵庫', '2024-05-19', '2021-03-24 12:52:03'),
(14, '缶詰', '鯖トマト煮', '冷蔵庫', '2021-09-18', '2021-03-24 12:52:29'),
(15, 'カレー', '野菜カレー', '押入れ', '2022-11-08', '2021-03-24 12:53:28'),
(16, 'カレー', '野菜カレー', '押入れ', '2022-11-08', '2021-03-24 12:53:28'),
(17, 'カレー', '野菜カレー', '押入れ', '2022-11-08', '2021-03-24 12:53:28'),
(18, 'カレー', 'キーマカレー', '押入れ', '2023-04-18', '2021-03-24 12:54:14'),
(19, 'カレー', 'キーマカレー', '押入れ', '2023-04-18', '2021-03-24 12:54:14'),
(20, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(21, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(22, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(23, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(24, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(25, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(26, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(27, '米', 'インスタントライス', '押入れ', '2025-08-03', '2021-03-24 12:54:56'),
(28, '米', 'インスタント玄米', '押入れ', '2024-11-18', '2021-03-24 12:55:32'),
(29, '米', 'インスタント玄米', '押入れ', '2024-11-18', '2021-03-24 12:55:32'),
(30, '米', 'インスタント玄米', '押入れ', '2024-11-18', '2021-03-24 12:55:32'),
(31, '米', 'インスタント玄米', '押入れ', '2024-11-18', '2021-03-24 12:55:32'),
(32, 'カレー', 'グリーンカレー', 'キチンキャビネット', '2021-04-25', '2021-03-24 14:55:37'),
(33, 'カレー', 'グリーンカレー', 'キチンキャビネット', '2021-04-25', '2021-03-24 14:55:37'),
(34, 'パスタ', 'スパゲティー', 'キチンキャビネット', '2024-06-15', '2021-03-24 14:56:32'),
(35, 'パスタ', 'スパゲティー', 'キチンキャビネット', '2024-06-15', '2021-03-24 14:56:32'),
(36, 'パスタ', 'スパゲティー', 'キチンキャビネット', '2024-06-15', '2021-03-24 14:56:32'),
(37, 'パスタ', 'スパゲティー', 'キチンキャビネット', '2024-06-15', '2021-03-24 14:56:32'),
(38, 'パスタ', 'トマトソース', '冷蔵庫', '2024-05-18', '2021-03-24 14:56:52'),
(39, 'パスタ', 'トマトソース', '冷蔵庫', '2024-05-18', '2021-03-24 14:56:52'),
(40, 'パスタ', 'トマトソース', '冷蔵庫', '2024-05-18', '2021-03-24 14:56:52');

-- --------------------------------------------------------

--
-- Table structure for table `user2`
--

CREATE TABLE `user2` (
  `id` int(12) NOT NULL,
  `category` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `item` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `expire` date NOT NULL,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user2`
--

INSERT INTO `user2` (`id`, `category`, `item`, `location`, `expire`, `indate`) VALUES
(1, '菓子類', '大福', '食卓', '2021-03-28', '2021-03-25 16:01:49'),
(2, '菓子類', '大福', '食卓', '2021-03-28', '2021-03-25 16:01:49'),
(3, '菓子類', 'チョコレート', '菓子引出し', '2022-01-27', '2021-03-25 16:03:01'),
(4, '菓子類', 'チョコレート', '菓子引出し', '2022-01-27', '2021-03-25 16:03:01'),
(6, '菓子類', 'お煎餅', '菓子引出し', '2022-05-08', '2021-03-25 16:04:00'),
(7, '菓子類', 'お煎餅', '菓子引出し', '2022-05-08', '2021-03-25 16:04:00'),
(21, '漬物', '梅干し', '冷蔵庫', '2022-08-11', '2021-03-25 16:05:40'),
(22, '漬物', 'キムチ', '冷蔵庫', '2021-05-24', '2021-03-25 16:31:29'),
(23, '漬物', 'しば漬', '冷蔵庫', '2021-04-05', '2021-03-25 16:33:03'),
(24, 'パン', 'フランスパン', '食卓', '2021-03-29', '2021-03-25 16:33:33');

-- --------------------------------------------------------

--
-- Table structure for table `user_id`
--

CREATE TABLE `user_id` (
  `id` int(5) NOT NULL,
  `user_nm` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_pw` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `life_flag` int(1) DEFAULT 0,
  `indate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_id`
--

INSERT INTO `user_id` (`id`, `user_nm`, `user_pw`, `life_flag`, `indate`) VALUES
(1, 'user1', 'pass1', 0, '2021-03-24 12:49:40'),
(2, 'user2', 'pass2', 0, '2021-03-24 16:21:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user1`
--
ALTER TABLE `user1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user2`
--
ALTER TABLE `user2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_id`
--
ALTER TABLE `user_id`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `user_nm` (`user_nm`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user1`
--
ALTER TABLE `user1`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `user2`
--
ALTER TABLE `user2`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_id`
--
ALTER TABLE `user_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
